define(
"dojo/cldr/nls/ca/currency", //begin v1.x content
{
	"HKD_displayName": "dòlar de Hong Kong",
	"CHF_displayName": "franc suís",
	"JPY_symbol": "JP¥",
	"CAD_displayName": "dòlar canadenc",
	"HKD_symbol": "HK$",
	"CNY_displayName": "iuan renmimbi xinès",
	"USD_symbol": "US$",
	"AUD_displayName": "dòlar australià",
	"JPY_displayName": "ien japonès",
	"CAD_symbol": "CA$",
	"USD_displayName": "dòlar dels Estats Units",
	"EUR_symbol": "€",
	"CNY_symbol": "¥",
	"GBP_displayName": "lliura esterlina britànica",
	"GBP_symbol": "£",
	"AUD_symbol": "AU$",
	"EUR_displayName": "euro"
}
//end v1.x content
);